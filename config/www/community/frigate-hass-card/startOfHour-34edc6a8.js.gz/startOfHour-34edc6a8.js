import{c_ as t}from"./card-e5d55e5b.js";function s(s){const n=t(s);return n.setMinutes(59,59,999),n}function n(s){const n=t(s);return n.setMinutes(0,0,0),n}export{s as e,n as s};
